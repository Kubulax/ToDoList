import React from "react";

export default class Task extends React.Component {
    constructor(title, description, deadline, priority){
        super();
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.priority = priority;
        this.finished = false;
    }

    editTask(task){
        this.title = task.title;
        this.description = task.description;
        this.deadline = task.deadline;
        this.priority = task.priority;
    }

    toggleState(){
        this.finished = !this.finished;
    }   
}