import React, { useState } from 'react';
import Task from '../classes/task'

export const List = ({ tasks, setTasks }) => {

  const [edit, setEdit] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  
  const handleDeleteTask = index => {
    const newTask = [...tasks];
    newTask.splice(index, 1);
    setTasks(newTask);

    if(tasks.length > 0)
    {
      localStorage.setItem('tasks', JSON.stringify([...tasks]));
    }
    else
    {
      localStorage.removeItem('tasks');
    }
    
    setEdit(false);
  };
  
  const handleFinishTask = index => {
    const newTask = [...tasks];
    newTask[index].toggleState();
    setTasks(newTask);
  };
  
  const assignColorToPriority = data => {
    if (data.priority === 'Wysoki') {
      return { color: 'red' };
    } else if (data.priority === 'Średni') {
      return { color: 'orange' };
    } else if (data.priority === 'Niski') {
      return { color: 'green' };
    }
  };
  
  const handleEditToggle = index => {
    setEditIndex(index);
    setEdit(!edit);
  };
  
  const handleEditTask = (index) => {
    const editedTitle = document.getElementById("editedTitle").value;
    const editedDescription = document.getElementById("editedDescription").value;
    const editedDeadline = document.getElementById("editedDeadline").value;
    const editedPriority = document.getElementById("editedPriority").value;

    const editedTask = [...tasks];
    editedTask[index].editTask(new Task(editedTitle, editedDescription, editedDeadline, editedPriority));
  
    setTasks(editedTask);

    localStorage.setItem('tasks', JSON.stringify([...tasks]));

    setEdit(false);
  };
  
  const [expandedDescriptionTasks, setExpandedDescriptionTasks] = useState([]);
  
  const handleToggleDescription = index => {
    if(!expandedDescriptionTasks.length)
    {
      setExpandedDescriptionTasks([...expandedDescriptionTasks, index]);
      return;
    }

    if(index in expandedDescriptionTasks)
    {
      const newExpandedDescriptionTasks = [...expandedDescriptionTasks];
      newExpandedDescriptionTasks.splice(index, 1);
      setExpandedDescriptionTasks(newExpandedDescriptionTasks);
    }
    else
    {
      setExpandedDescriptionTasks([...expandedDescriptionTasks, index]);
    }
  };

  return (
    <ul>
      {tasks.length ? tasks.map((task, index) => {
        let description = "";
        let isExpanded = false;
        if(index in expandedDescriptionTasks)
        {
          description = task.description;
          isExpanded = true;
        }
        else
        {
          description = task.description?.substring(0, 10);
        }

        return (
          <li key={index} style={{ textDecoration: task.finished ? 'line-through' : '' }}>
            <span>
              <strong>Tytuł: </strong>
              {edit && editIndex === index ? (
                <input type='text' defaultValue={task.title} id="editedTitle" />
              ) : (
                <span>{task.title}</span>
              )}
            </span>
            <br />
            <span>
              <strong>Opis: </strong>
              {edit && editIndex === index ? (
                <textarea type='text' defaultValue={task.description} id="editedDescription" />
              ) : (
                <span>
                  {description} &nbsp;

                  <button style={{ visibility: description.length > 10 ? 'visible' : 'hidden' }} onClick={() => handleToggleDescription(index)}>{isExpanded ? 'Pokaż mniej' : 'Pokaż więcej'}</button>
                </span>
              )}
            </span>
            <br />
            <span>
              <span>
                <strong>Priorytet: </strong>
              </span>
              {edit && editIndex === index ? (
                <select defaultValue={task.priority} id="editedPriority">
                  <option value='Wysoki'>Wysoki</option>
                  <option value='Średni'>Średni</option>
                  <option value='Niski'>Niski</option>
                </select>
              ) : (
                <span>
                  <strong>Priorytet:</strong> <span style={assignColorToPriority(task)}> {task.priority} </span>
                </span>
              )}
            </span>
            <br />
            <strong>Termin wykonania: </strong>
              {edit && editIndex === index ? (
                <input type='date' defaultValue={task.deadline} id="editedDeadline" />
              ) : (
                task.deadline
              )}
            <br />
            <button onClick={() => handleDeleteTask(index)}>Usuń</button>
            <button onClick={() => handleFinishTask(index)}>{task.finished ? "Ponów" : "Ukończ"}</button>
            <br />
            <span>Edytuj</span>
            <input type='checkbox' checked={edit && editIndex === index} onChange={() => handleEditToggle(index)} />
            <button
              style={{ visibility: edit && editIndex === index ? 'visible' : 'hidden' }}
              onClick={() => handleEditTask(index)}>
              Edytuj
            </button>
            <br />
            <br />
          </li>
        );
      }) : <p>Lista jest pusta</p>}
    </ul>
  );
}