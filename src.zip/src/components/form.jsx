import Task from '../classes/task'

export const Form = ({ tasks, setTasks }) => {
    const handleAddTask = () => {
        const title = document.getElementById('title').value;
        const description = document.getElementById('description').value;
        const date = document.getElementById('date').value;
        const priority = document.getElementById('priority').value;

        if(title !== "" && description !== "" && date !== "" && priority !== "")
        {
            var task = new Task(title, description, date, priority);
            setTasks([...tasks, task]);

            document.getElementById('title').value = '';
            document.getElementById('description').value = '';
            document.getElementById('date').value = '';
            document.getElementById('priority').value = '';
        }
        else
        {
            alert("Proszę uzupełnić wszystkie dane");
        }  
    };

    const handleSaveTasks = ({ tasks, setTasks }) => {
        localStorage.setItem('tasks', JSON.stringify([...tasks]));
    }

    return (
        <div>
        <h1>Dodaj zadanie</h1>

        <strong>Tytuł </strong>
        <input type='text' id='title' />
        <br></br>
        <strong>Opis </strong>
        <textarea type='text' id='description' />
        <br></br>
        <strong>Termn wykonania </strong>
        <input type='date' id='date' />
        <br></br>
        <strong>Priorytet </strong>
        <select id='priority' defaultValue={''}>
            <option value='' disabled hidden>Wybierz priorytet</option>
            <option value='Wysoki'>Wysoki</option>
            <option value='Średni'>Średni</option>
            <option value='Niski'>Niski</option>
        </select>
        <br></br>
        <button onClick={handleAddTask}>Dodaj</button>
        <br />
        <br />
        <button onClick={handleSaveTasks}>Zapisz stan aplikacji</button>
        </div>
    );
};